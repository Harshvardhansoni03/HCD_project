#ifndef _OPT_ARG_H_
#define _OPT_ARG_H_

/*--------------------------------------------------------------------------------*/
/* Includes */
/*--------------------------------------------------------------------------------*/

#include "pp_narg.h"
#include "splice.h"

/* If you are Joseph Jaoudi, you have a snippet which expands into an
   example. If you are not Joseph, but possess his code, study the examples. If
   you have no examples, turn back contact Joseph. */

#endif /* _OPT_ARG_H_ */
